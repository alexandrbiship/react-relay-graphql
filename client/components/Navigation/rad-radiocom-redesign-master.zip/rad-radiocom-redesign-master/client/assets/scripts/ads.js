(function() {
  window.canRunAds = true;
})();
