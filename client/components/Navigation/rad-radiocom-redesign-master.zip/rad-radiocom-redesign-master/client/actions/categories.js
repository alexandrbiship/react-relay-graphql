import * as C from 'client/constants';

export const categoriesLoad = categories => ({ type: C.LOAD_CATEGORIES, categories });
