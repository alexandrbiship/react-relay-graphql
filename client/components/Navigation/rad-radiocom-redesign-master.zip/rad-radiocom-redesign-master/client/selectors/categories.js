// get 'categories' state
export const selectCategories = state => state.categories;
