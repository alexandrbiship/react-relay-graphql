export const showGeolocationModal = state => state.geolocation.showGeolocationModal;

export const getCityName = state => state.geolocation.cityName;

export const getMarketId = state => state.geolocation.markets[0];
