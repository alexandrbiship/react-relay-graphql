// get 'errorLog' state
export const selectErrorLog = state => state.errorLog;
