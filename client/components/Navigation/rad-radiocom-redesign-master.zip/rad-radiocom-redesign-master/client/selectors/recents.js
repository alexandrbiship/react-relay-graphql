// get 'schedules' state
export const selectRecents = state => state.recents;
