import PropTypes from 'prop-types';

export const propTypes = {
  // loginUser: PropTypes.func,
  // loggedIn: PropTypes.func,
  marketId: PropTypes.number,
};

export const defaultProps = {
  // loginUser: () => null,
  // loggedIn: () => null,
};

