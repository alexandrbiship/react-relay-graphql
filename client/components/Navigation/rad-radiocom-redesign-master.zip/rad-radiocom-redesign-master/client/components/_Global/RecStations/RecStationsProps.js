import PropTypes from 'prop-types';

export const propTypes = {
  recStations: PropTypes.object,
};

export const defaultProps = {
  recStations: {},
};
