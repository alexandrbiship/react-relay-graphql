import PropTypes from 'prop-types';

export const propTypes = {
  fetchGeolocation: PropTypes.func,
  setMarkets: PropTypes.func,
  toggleGeolocationModal: PropTypes.func,
};
