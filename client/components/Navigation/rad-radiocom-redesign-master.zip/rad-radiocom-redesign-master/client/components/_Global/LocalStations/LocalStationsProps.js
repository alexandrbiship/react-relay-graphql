import PropTypes from 'prop-types';

export const propTypes = {
  localStations: PropTypes.object,
};

export const defaultProps = {
  localStations: {},
};
