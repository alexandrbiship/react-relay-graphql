import PropTypes from 'prop-types';

export const propTypes = {
  recPodcasts: PropTypes.object,
};

export const defaultProps = {
  recPodcasts: {},
};
