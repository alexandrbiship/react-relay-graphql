/**
 * Enable import/export
 */
require('babel-register');
require('babel-polyfill');

/**
 * Entry Script
 */
require('./server/server');
